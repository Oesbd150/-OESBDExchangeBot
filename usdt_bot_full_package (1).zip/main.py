import os
from dotenv import load_dotenv

load_dotenv()

print("Bot is starting...")
# Your Telegram bot code goes here
